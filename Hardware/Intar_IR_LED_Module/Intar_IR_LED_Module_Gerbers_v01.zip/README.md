Fabrication Notes
-----------------

1. PCB material: FR-4
2. PCB thickness: 0.063 inches
3. Copper weight: 1 oz.
4. Surface finish: HASL
5. Layers: 2

Gerber Files
------------

.GTL    - Top layer
.GBL    - Bottom layer
.GTS    - Solder stop mask top
.GBS    - Solder stop mask bottom
.GTO    - Silk top
.GBO    - Silk bottom
.TXT    - NC Drill
.GKO    - Outline layer